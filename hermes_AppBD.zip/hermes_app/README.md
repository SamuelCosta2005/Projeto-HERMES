# Hermes — app Flutter (v2, com Firebase)

App de pedido e controle de materiais entregues pelo robô Hermes. Mantém o visual
do protótipo original (tema escuro ciano / claro laranja, botão de sol e lua em
todas as telas) e agora funciona de verdade, ligado ao Firebase.


## Como funciona (sem servidor)

O app fala **direto com o Firestore** (como o Xeque). Não existe backend, não
usa Cloud Functions e **não precisa do plano pago** (funciona no Spark).
As regras de estoque (reserva, consumo, devolução, baixa, contagem) rodam
dentro do app, em transações do Firestore, então duas pessoas nunca levam a
mesma última unidade.

Consequência: as regras de segurança do banco ficam abertas para qualquer
usuário logado. É uma versão **de teste**.

## Como entra

Sem e-mail, sem cadastro:

- **Entrar** → entra como **cliente**.
- **Sou do suporte técnico** (cadeado) → pede a senha **1234** → entra como **admin**.

A senha fica em `lib/config.dart` (`kSenhaAdmin`). Só existem dois papéis: o
admin **é** o suporte técnico.

| | Cliente | Admin (suporte técnico) |
|---|:-:|:-:|
| Pedir: materiais → sala → pedido aprovado → fila → mapa → confirmar recebimento | ✅ | ✅ |
| Meus itens: pedidos, empréstimos, pedir recolhimento | ✅ | ✅ |
| Entregas: fila completa, iniciar rota, marcar chegada | | ✅ |
| Empréstimos: receber devolução (bom, danificado, perdido) | | ✅ |
| Estoque: entrada, contagem, baixa | | ✅ |
| Cadastrar/editar/desativar itens, histórico de movimentações | | ✅ |
| Cadastrar/editar/excluir locais (salas): Estoque → ícone da porta | | ✅ |

**Fila privada:** quem espera vê só "3º na fila, 2 pedidos à frente". Código,
destino e itens de outros pedidos não aparecem na tela.

## Passo a passo

1. **Console do Firebase → Authentication → Sign-in method → ative "Anônimo".**
2. **Firestore → Regras:** cole o conteúdo de `firebase/regras-firestore.txt`
   (as instruções estão no topo do arquivo) e clique em **Publicar**.
3. **Locais:** entre como admin → Estoque → ícone da porta no topo → **Novo local**.
   (Se o SInergic já tem salas em `locais_eventos`, elas aparecem sozinhas.)
4. **Crie o projeto Flutter e copie os arquivos**
   ```bash
   flutter create hermes_app
   ```
   Copie `lib/`, `pubspec.yaml` e `analysis_options.yaml` deste pacote por cima.
5. **Conecte ao Firebase**
   ```bash
   dart pub global activate flutterfire_cli
   flutterfire configure
   ```
6. **Rode**
   ```bash
   flutter pub get
   flutter run
   ```
   Para gerar o APK: `flutter build apk`.
7. Entre como admin (cadeado, `1234`) → aba **Estoque** → **+** para cadastrar
   os primeiros itens. Os locais são cadastrados pelo ícone da porta, na mesma tela.

### Índices
Algumas listas precisam de índice no Firestore. Se uma tela mostrar erro de
índice, olhe o terminal do `flutter run`: o erro traz um **link**. Abra o link,
clique em **Criar índice** e espere 1 a 2 minutos. Repita para cada tela que
pedir. (A lista completa está em `firebase/indices.json`.)

## Estrutura

```
lib/
  main.dart  config.dart  firebase_options.dart
  theme/      cores e textos (claro/escuro), tema
  models/     Pedido, Emprestimo, ItemEstoque, Local, FilaInfo, Movimentacao, Perfil...
  services/   AuthService (entrar anônimo), HermesApi (regras de estoque e pedidos no Firestore), Sessao (perfil atual)
  data/       leituras em tempo real do Firestore (itens, pedidos, empréstimos, locais, movimentações)
  utils/      formatadores, ícones, andares, mensagens de erro
  widgets/    componentes (cards, botões, estados, diálogos...)
  screens/
    auth/     login, porteiro (AuthGate), sem acesso
    home_shell.dart        abas por papel
    pedir/    materiais, sala, aprovado, fila, mapa, recebimento
    meus_itens_screen.dart
    equipe/   entregas, empréstimos, devolução, estoque, item, ações, cadastro, movimentações
```

## Premissas (diga se alguma estiver errada)

- **Login simplificado** (anônimo + senha 1234 do admin) e Firestore aberto: só para testes.
- **`locais_eventos` precisa ser legível por usuário logado.** A tela de sala lê essa coleção direto (as regras dela são as que já existem no projeto de vocês).
- **A fila se atualiza sozinha a cada 15 segundos** e quando o status do seu pedido muda.
- **Mapa em tempo real:** continua um espaço reservado ("Mapa não encontrado"), como combinado. A tela mostra o status real e as etapas (Na fila → A caminho → Chegou).
- **Setor do solicitante:** o app não envia setor.
- **Usuários:** ficam na coleção própria `hermes_usuarios` (não mexe na `usuarios` do SInergic). Cada "Entrar" cria um usuário anônimo novo; dá para apagar esses documentos depois dos testes.
- **Estoque baixo** = disponível abaixo do estoque mínimo do item.

## O que foi verificado — e o que NÃO foi

**Não foi compilado nem executado.** O ambiente onde isto foi escrito não tem o
Flutter SDK, então ninguém rodou `flutter run` nem `flutter analyze` neste código.

O que foi checado (fora do Flutter): a sintaxe de todos os arquivos `.dart`, com um parser de Dart. A lógica de estoque (reserva, consumo, devolução, baixa, contagem) é a mesma que foi testada em 91 testes automáticos na versão com servidor, mas **esta versão em Dart não foi testada**.

Isso pega o erro de digitação, mas **não pega erro de tipo**. Se `flutter run`
reclamar de algo, me mande a mensagem inteira que eu corrijo.

## Se algo der errado

- **"requires an index"** ao abrir uma lista: falta criar um índice do Firestore (use o link que aparece no terminal; veja "Índices" acima).
- **"permission-denied"** nas listas: as regras de `firebase/regras-firestore.txt` ainda não foram publicadas.
- **Erro de `minSdkVersion` no Android**: em `android/app/build.gradle`, ajuste `minSdkVersion` para 23.
- **Conflito de versões do Firebase**: o `pubspec.yaml` usa a família `firebase_core ^3`; não misture com pacotes Firebase da família 4.
