import 'package:flutter/material.dart';
import '../../data/pedidos_repository.dart';
import '../../models/pedido.dart';
import '../../services/hermes_api.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_text_styles.dart';
import '../../utils/formatadores.dart';
import '../../widgets/app_card.dart';
import '../../widgets/chips_status.dart';
import '../../widgets/dialogs.dart';
import '../../widgets/estados.dart';
import '../../widgets/hermes_app_bar.dart';
import '../../widgets/primary_button.dart';

/// Equipe: fila completa de entregas e avanço do status (a caminho / chegou).
class EntregasScreen extends StatefulWidget {
  const EntregasScreen({super.key});

  @override
  State<EntregasScreen> createState() => _EntregasScreenState();
}

class _EntregasScreenState extends State<EntregasScreen> {
  late final Stream<List<Pedido>> _pedidos;
  final Set<String> _ocupados = <String>{};

  @override
  void initState() {
    super.initState();
    _pedidos = PedidosRepository().watchAtivos();
  }

  Future<void> _avancar(Pedido p) async {
    final novo = p.status == StatusPedido.queued ? 'inTransit' : 'arrived';
    setState(() => _ocupados.add(p.id));
    try {
      await HermesApi.instance.atualizarStatusEntrega(p.id, novo);
    } catch (e) {
      if (mounted) mostrarErro(context, e);
    } finally {
      if (mounted) setState(() => _ocupados.remove(p.id));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: HermesAppBar(stageBadge: 'Entregas'),
      body: SafeArea(
        top: false,
        child: StreamBuilder<List<Pedido>>(
          stream: _pedidos,
          builder: (context, snap) {
            if (snap.hasError) return EstadoErro(erro: snap.error!);
            if (!snap.hasData) return EstadoCarregando();
            final pedidos = snap.data!;
            if (pedidos.isEmpty) {
              return EstadoVazio(
                icone: Icons.local_shipping_outlined,
                titulo: 'Nenhuma entrega pendente',
                subtitulo: 'Os pedidos novos aparecem aqui na ordem da fila.',
              );
            }
            return ListView(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
              children: [
                Text('Fila de entregas', style: AppTextStyles.screenTitle),
                const SizedBox(height: 4),
                Text(
                  '${pedidos.length} pedido(s) ativo(s), do mais antigo para o mais novo.',
                  style: AppTextStyles.screenSubtitle,
                ),
                const SizedBox(height: 16),
                for (var i = 0; i < pedidos.length; i++)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: _CartaoEntrega(
                      posicao: i + 1,
                      pedido: pedidos[i],
                      ocupado: _ocupados.contains(pedidos[i].id),
                      onAvancar: () => _avancar(pedidos[i]),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _CartaoEntrega extends StatelessWidget {
  final int posicao;
  final Pedido pedido;
  final bool ocupado;
  final VoidCallback onAvancar;

  const _CartaoEntrega({
    required this.posicao,
    required this.pedido,
    required this.ocupado,
    required this.onAvancar,
  });

  @override
  Widget build(BuildContext context) {
    final p = pedido;
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 26,
                height: 26,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.surfaceAlt,
                  border: Border.all(color: AppColors.border),
                ),
                child: Text(
                  '$posicao',
                  style: TextStyle(color: AppColors.textSecondary, fontSize: 12, fontWeight: FontWeight.w800),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(child: Text(p.codigo, style: AppTextStyles.cardTitle)),
              chipStatusPedido(p.status),
            ],
          ),
          const SizedBox(height: 12),
          _Linha(icone: Icons.person_outline_rounded, texto: p.solicitanteComSetor),
          const SizedBox(height: 6),
          _Linha(
            icone: Icons.place_outlined,
            texto: p.localDetalhe.isEmpty ? p.localNome : '${p.localNome} · ${p.localDetalhe}',
          ),
          const SizedBox(height: 6),
          _Linha(icone: Icons.inventory_2_outlined, texto: p.resumoItens),
          const SizedBox(height: 6),
          _Linha(icone: Icons.schedule_rounded, texto: 'Pedido ${horaRelativa(p.criadoEm)}'),
          const SizedBox(height: 14),
          if (p.status == StatusPedido.queued)
            PrimaryButton(
              label: 'Iniciar rota',
              icon: Icons.play_arrow_rounded,
              isLoading: ocupado,
              onPressed: onAvancar,
            )
          else if (p.status == StatusPedido.inTransit)
            PrimaryButton(
              label: 'Marcar chegada',
              icon: Icons.flag_rounded,
              isLoading: ocupado,
              onPressed: onAvancar,
            )
          else
            Text(
              'Aguardando o solicitante confirmar o recebimento.',
              style: AppTextStyles.cardSubtitle.copyWith(color: AppColors.success),
            ),
        ],
      ),
    );
  }
}

class _Linha extends StatelessWidget {
  final IconData icone;
  final String texto;

  const _Linha({required this.icone, required this.texto});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icone, size: 15, color: AppColors.textMuted),
        const SizedBox(width: 8),
        Expanded(child: Text(texto, style: AppTextStyles.cardSubtitle.copyWith(color: AppColors.textPrimary))),
      ],
    );
  }
}
