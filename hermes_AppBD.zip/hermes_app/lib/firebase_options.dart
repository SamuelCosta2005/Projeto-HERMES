import 'package:firebase_core/firebase_core.dart';

/// ⚠️ ARQUIVO PLACEHOLDER — substitua rodando `flutterfire configure`.
///
/// Esse comando conecta o app ao SEU projeto Firebase e gera este arquivo de
/// verdade, com as chaves de Android/iOS/Web. Instruções no README.md.
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    throw UnsupportedError(
      'firebase_options.dart ainda não foi configurado.\n'
      'Rode: flutterfire configure\n'
      '(veja o README.md, seção "Conectar ao Firebase")',
    );
  }
}
