import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/pedido.dart';

class PedidosRepository {
  final CollectionReference<Map<String, dynamic>> _col =
      FirebaseFirestore.instance.collection('pedidos_hermes');

  List<Pedido> _lista(QuerySnapshot<Map<String, dynamic>> s) =>
      s.docs.map((d) => Pedido.deDoc(d.id, d.data())).toList();

  /// Meus pedidos. As regras exigem o filtro por solicitanteId.
  Stream<List<Pedido>> watchMeus(String uid) {
    return _col
        .where('solicitanteId', isEqualTo: uid)
        .orderBy('criadoEm', descending: true)
        .limit(50)
        .snapshots()
        .map(_lista);
  }

  Stream<Pedido?> watchPedido(String id) {
    return _col.doc(id).snapshots().map((d) {
      final dados = d.data();
      return dados == null ? null : Pedido.deDoc(d.id, dados);
    });
  }

  /// Fila completa de pedidos ativos. Só técnico/admin conseguem ler.
  Stream<List<Pedido>> watchAtivos() {
    return _col
        .where('status', whereIn: ['queued', 'inTransit', 'arrived'])
        .orderBy('criadoEm')
        .snapshots()
        .map(_lista);
  }
}
