import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/movimentacao.dart';

/// Livro de movimentações de estoque. Só o admin consegue ler.
class MovimentacoesRepository {
  final CollectionReference<Map<String, dynamic>> _col =
      FirebaseFirestore.instance.collection('movimentacoes_estoque');

  Stream<List<Movimentacao>> watchRecentes({String? itemId, int limite = 100}) {
    Query<Map<String, dynamic>> q = _col;
    if (itemId != null) {
      q = q.where('itemId', isEqualTo: itemId);
    }
    q = q.orderBy('criadoEm', descending: true).limit(limite);
    return q.snapshots().map(
          (s) => s.docs.map((d) => Movimentacao.deDoc(d.id, d.data())).toList(),
        );
  }
}
