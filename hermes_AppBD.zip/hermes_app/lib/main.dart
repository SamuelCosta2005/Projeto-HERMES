import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'config.dart';
import 'firebase_options.dart';
import 'screens/auth/auth_gate.dart';
import 'theme/app_colors.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  if (kUsarEmulador) {
    FirebaseFirestore.instance.useFirestoreEmulator(kEmuladorHost, 8080);
    await FirebaseAuth.instance.useAuthEmulator(kEmuladorHost, 9099);
  }

  runApp(const HermesApp());
}

class HermesApp extends StatelessWidget {
  const HermesApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Reconstrói o app inteiro quando o botão de sol/lua troca o tema.
    return ValueListenableBuilder<bool>(
      valueListenable: AppColors.themeIsDark,
      builder: (context, isDark, _) {
        return MaterialApp(
          title: 'Hermes',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.current,
          // Sem `const` de propósito: widget const não reconstrói na troca de tema.
          home: AuthGate(),
        );
      },
    );
  }
}
